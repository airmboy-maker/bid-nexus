<meta http-equiv="refresh" content="0; url=https://bid-nexus-v2.streamlit.app"><script>window.location.replace("https://bid-nexus-v2.streamlit.app");</script>

# ⚡ [여기를 터치하면 BID-NEXUS v3.0 터미널이 즉시 실행됩니다](https://bid-nexus-v2.streamlit.app)

# 👑 BID-NEXUS v20.4-perfect-100 마스터 운용 매뉴얼 & CLI 치트키

- **시스템 버전**: `v20.4-perfect-100` (Genspark 4차 최종 감사 PASS + R1/R2/R3 코드 위생 100점 완결판)
- **핵심 산식 모듈**: `bid_math_fixed.py` (`decimal.ROUND_CEILING` / `ROUND_FLOOR` 원단위 절상·절사, `87.745%` 하한율 단일화, `15C4 = 1,365` 양자계단 스냅 — 1원 미달 오차율 0.0%)

---

## 🧭 1. (주)진경종합건설 공무팀 실전 입찰 1분 표준 운용 절차 (웹 대시보드 SOP)
1. **STEP 1 (`BAY 01 보물섬`, 15초)**: 상단 공고 레이더(강원권 건축공고 8건 기본 탑재)에서 공고를 선택하고 `자동 모델 추천 스위치`와 `예상 경쟁업체 수` 슬라이더를 맞춘 뒤 **최종 추천 투찰가**와 **행운의 번호 4개**를 확인합니다.
2. **STEP 2 (`킬포인트 KP-01~03`, 15초)**: 5대 사정 모델 버튼을 눌러 우리 투찰가가 붉은색 과밀 데드존(`M1`)을 피해 에메랄드빛 골든 크레바스 협곡(`KP-01`)에 위치하는지 확인합니다.
3. **STEP 3 (`BAY 02 장바구니`, 10초)**: 당사 수행능력 점수가 `30.0점` 만점에 미달할 경우 **적격점수 부족분 만회 역산기**를 켜서 종합 `95.0점` 달성용 필수 상향 투찰가를 확인합니다.
4. **STEP 4 (`나라장터 실투찰`, 10초)**: 추천 예가번호 4개 중 2개를 선택하고 최종 투찰금액(원)을 입력한 뒤 기초금액·A값·하한율(`87.745%`) 기준과 육안 대조 후 투찰합니다.
5. **STEP 5 (`BAY 06 아카데미`, 10초)**: 개찰 후 실제 확정 사정률을 입력해 모델별 신뢰도(`Trust Score`)를 누적하고 `인쇄용 표준 사정 교본`을 출력해 보관합니다.

---

## ⚡ 2. 터미널 0.1초 초고속 실전 CLI 3대 무기 사용법 (`~/bid-nexus`)

### ① 단건 실전 정밀 타격기 (`./bid.sh`)
- **기본 만점(30.0점) 기준 타격**:
  `cd ~/bid-nexus && ./bid.sh "202611-00892" "3,605,411,000" "170,640,956"`
- **수행능력 점수 미달(예: 29.2점) 시 역산 보정 타격**:
  `cd ~/bid-nexus && ./bid.sh "202611-00892" "3,605,411,000" "170,640,956" "87.745" "29.2"`

### ② 강원권 8대 공고 전수 일괄 타격 브리핑 (`./batch_bid.sh`)
- **30.0점 만점 기준 8대 공고 일괄 출력**:
  `cd ~/bid-nexus && ./batch_bid.sh`
- **수행능력 미달(예: 29.5점) 기준 8대 공고 일괄 역산 출력**:
  `cd ~/bid-nexus && ./batch_bid.sh 29.5`

### ③ 개찰 완료 공고 5대 모델 오차 복기 & MVP 판정기 (`./review.sh`)
- **실제 개찰 사정률(예: 100.0885%) 입력 복기**:
  `cd ~/bid-nexus && ./review.sh "202611-00892" "3,605,411,000" "170,640,956" "100.0885"`

---

## 🔒 3. 로컬 API 키 및 텔레그램 토큰 보안 설정 (`.streamlit/secrets.toml`)
- 터미널 실행: `open -a TextEdit ~/bid-nexus/.streamlit/secrets.toml` (`.gitignore`에 의해 외부 유출 원천 차단)

---

## 🛡️ 4. 1초 마스터 복구 치트키 (언제든 `v20.4-perfect-100` 완전체로 복원)
- 터미널 실행:
  `cd ~/bid-nexus && git fetch --all --tags && git checkout v2-dev && git checkout v20.4-perfect-100 && git checkout main && git reset --hard v20.4-perfect-100 && git push -f origin main && git checkout v2-dev`
